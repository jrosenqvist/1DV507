package jr222wb_assign1.ferrySystem;

public class Lorry extends Vehicle {
	Lorry() {
		super(2, 8);
	}
}
