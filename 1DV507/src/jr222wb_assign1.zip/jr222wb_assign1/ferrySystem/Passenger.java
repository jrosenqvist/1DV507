package jr222wb_assign1.ferrySystem;

public class Passenger {
 // EMPTY :(
}
