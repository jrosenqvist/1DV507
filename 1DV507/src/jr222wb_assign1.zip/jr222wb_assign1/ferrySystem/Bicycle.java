package jr222wb_assign1.ferrySystem;

public class Bicycle extends Vehicle {
	Bicycle() {
		super(1,0); //Provides 0 size, the ferry has a special system to keep track of bicycles
	}
}
