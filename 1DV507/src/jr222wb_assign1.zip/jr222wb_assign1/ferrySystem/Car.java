package jr222wb_assign1.ferrySystem;

public class Car extends Vehicle {
	Car() {
		super(4, 1);		
	}
}
