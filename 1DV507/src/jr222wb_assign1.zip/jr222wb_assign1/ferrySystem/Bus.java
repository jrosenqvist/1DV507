package jr222wb_assign1.ferrySystem;

public class Bus extends Vehicle {
	Bus() {
		super(20, 4);
	}
}
